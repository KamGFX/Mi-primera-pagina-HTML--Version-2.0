"use client"

import { useRef, useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const categories = [
  "Todos",
  "Música",
  "En vivo",
  "Videojuegos",
  "Comedia",
  "Cocina",
  "Noticias",
  "Animación",
  "Deportes",
  "Ciencia y tecnología",
  "Aprendizaje",
  "Naturaleza",
  "Moda",
  "Podcasts",
  "Películas",
  "Historia",
  "Recién subidos",
  "Vistos",
]

export function CategoryPills() {
  const [selected, setSelected] = useState("Todos")
  const [showLeftArrow, setShowLeftArrow] = useState(false)
  const [showRightArrow, setShowRightArrow] = useState(true)
  const containerRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (!containerRef.current) return
    const scrollAmount = direction === "left" ? -200 : 200
    containerRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" })
  }

  const handleScroll = () => {
    if (!containerRef.current) return
    const { scrollLeft, scrollWidth, clientWidth } = containerRef.current
    setShowLeftArrow(scrollLeft > 0)
    setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 10)
  }

  return (
    <div className="relative">
      {showLeftArrow && (
        <div className="absolute left-0 top-0 bottom-0 flex items-center z-10 bg-gradient-to-r from-background via-background to-transparent pr-8">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={() => scroll("left")}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
        </div>
      )}
      
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex gap-3 overflow-x-auto scrollbar-hide py-3 px-1"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {categories.map((category) => (
          <Button
            key={category}
            variant={selected === category ? "default" : "secondary"}
            className={cn(
              "rounded-lg whitespace-nowrap h-8 px-3 text-sm font-medium",
              selected === category 
                ? "bg-foreground text-background hover:bg-foreground/90" 
                : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
            )}
            onClick={() => setSelected(category)}
          >
            {category}
          </Button>
        ))}
      </div>

      {showRightArrow && (
        <div className="absolute right-0 top-0 bottom-0 flex items-center z-10 bg-gradient-to-l from-background via-background to-transparent pl-8">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={() => scroll("right")}
          >
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>
      )}
    </div>
  )
}
