"use client"

import { useState } from "react"
import { Header } from "@/components/youtube/header"
import { Sidebar } from "@/components/youtube/sidebar"
import { CategoryPills } from "@/components/youtube/category-pills"
import { VideoGrid } from "@/components/youtube/video-grid"
import { cn } from "@/lib/utils"

export default function YouTubeClone() {
  const [sidebarOpen, setSidebarOpen] = useState(true)

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuClick={() => setSidebarOpen(!sidebarOpen)} />
      <Sidebar isOpen={sidebarOpen} />
      
      <main 
        className={cn(
          "pt-14 transition-all duration-200",
          sidebarOpen ? "md:ml-60" : "md:ml-[72px]"
        )}
      >
        <div className="sticky top-14 bg-background z-30 px-4 md:px-6 border-b border-border">
          <CategoryPills />
        </div>
        
        <div className="p-4 md:p-6">
          <VideoGrid />
        </div>
      </main>
    </div>
  )
}
