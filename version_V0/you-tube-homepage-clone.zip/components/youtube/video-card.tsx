"use client"

import { MoreVertical } from "lucide-react"
import { Button } from "@/components/ui/button"

interface VideoCardProps {
  thumbnail: string
  duration: string
  title: string
  channel: string
  channelAvatar: string
  views: string
  uploadedAt: string
}

export function VideoCard({
  thumbnail,
  duration,
  title,
  channel,
  channelAvatar,
  views,
  uploadedAt,
}: VideoCardProps) {
  return (
    <div className="group cursor-pointer">
      {/* Thumbnail */}
      <div className="relative aspect-video rounded-xl overflow-hidden bg-muted">
        <img
          src={thumbnail}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
        />
        <span className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1 py-0.5 rounded font-medium">
          {duration}
        </span>
      </div>

      {/* Info */}
      <div className="flex gap-3 mt-3">
        <div className="shrink-0">
          <div className="h-9 w-9 rounded-full bg-primary overflow-hidden flex items-center justify-center text-primary-foreground text-sm font-medium">
            {channelAvatar.startsWith("http") ? (
              <img src={channelAvatar} alt={channel} className="w-full h-full object-cover" />
            ) : (
              channelAvatar
            )}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-sm leading-5 line-clamp-2 text-foreground group-hover:text-foreground/90">
            {title}
          </h3>
          <p className="text-muted-foreground text-sm mt-1 hover:text-foreground">
            {channel}
          </p>
          <p className="text-muted-foreground text-sm">
            {views} • {uploadedAt}
          </p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <MoreVertical className="h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
