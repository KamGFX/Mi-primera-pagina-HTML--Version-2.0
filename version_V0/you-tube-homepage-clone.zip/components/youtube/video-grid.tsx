"use client"

import { VideoCard } from "./video-card"

const videos = [
  {
    id: "1",
    thumbnail: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=640&h=360&fit=crop",
    duration: "12:34",
    title: "Los mejores momentos del stream de ayer - Compilación épica",
    channel: "GamingPro",
    channelAvatar: "G",
    views: "1.2M vistas",
    uploadedAt: "hace 2 días",
  },
  {
    id: "2",
    thumbnail: "https://images.unsplash.com/photo-1493711662062-fa541f7f3d24?w=640&h=360&fit=crop",
    duration: "25:18",
    title: "Receta fácil: Cómo hacer la mejor pasta carbonara auténtica italiana",
    channel: "Chef Cocina",
    channelAvatar: "C",
    views: "890K vistas",
    uploadedAt: "hace 5 días",
  },
  {
    id: "3",
    thumbnail: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=640&h=360&fit=crop",
    duration: "18:45",
    title: "Explorando el universo: Nuevos descubrimientos del telescopio James Webb",
    channel: "Ciencia y Más",
    channelAvatar: "C",
    views: "2.1M vistas",
    uploadedAt: "hace 1 semana",
  },
  {
    id: "4",
    thumbnail: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=640&h=360&fit=crop",
    duration: "8:22",
    title: "Tutorial de guitarra para principiantes - Aprende tus primeros acordes",
    channel: "Música Fácil",
    channelAvatar: "M",
    views: "456K vistas",
    uploadedAt: "hace 3 días",
  },
  {
    id: "5",
    thumbnail: "https://images.unsplash.com/photo-1504805572947-34fad45aed93?w=640&h=360&fit=crop",
    duration: "15:30",
    title: "5 hábitos que cambiarán tu vida - Desarrollo personal y productividad",
    channel: "Motivación Diaria",
    channelAvatar: "M",
    views: "3.4M vistas",
    uploadedAt: "hace 2 semanas",
  },
  {
    id: "6",
    thumbnail: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=640&h=360&fit=crop",
    duration: "22:10",
    title: "Los lugares más increíbles para visitar en Japón - Guía completa de viaje",
    channel: "Viajero del Mundo",
    channelAvatar: "V",
    views: "1.8M vistas",
    uploadedAt: "hace 4 días",
  },
  {
    id: "7",
    thumbnail: "https://images.unsplash.com/photo-1461896836934- voices-video-app?w=640&h=360&fit=crop",
    duration: "31:45",
    title: "Análisis completo del nuevo iPhone 16 Pro - ¿Vale la pena comprarlo?",
    channel: "Tech Review",
    channelAvatar: "T",
    views: "5.2M vistas",
    uploadedAt: "hace 1 día",
  },
  {
    id: "8",
    thumbnail: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=640&h=360&fit=crop",
    duration: "1:24:30",
    title: "Final épica del torneo mundial - Mejores jugadas y momentos históricos",
    channel: "Esports TV",
    channelAvatar: "E",
    views: "4.7M vistas",
    uploadedAt: "hace 6 horas",
  },
  {
    id: "9",
    thumbnail: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=640&h=360&fit=crop",
    duration: "45:20",
    title: "Curso de programación: Aprende React desde cero en un solo video",
    channel: "Dev Academy",
    channelAvatar: "D",
    views: "987K vistas",
    uploadedAt: "hace 1 mes",
  },
  {
    id: "10",
    thumbnail: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=640&h=360&fit=crop",
    duration: "16:55",
    title: "Rutina de ejercicios en casa - 30 minutos para estar en forma",
    channel: "Fitness Total",
    channelAvatar: "F",
    views: "2.3M vistas",
    uploadedAt: "hace 3 semanas",
  },
  {
    id: "11",
    thumbnail: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=640&h=360&fit=crop",
    duration: "28:15",
    title: "Las 10 películas más esperadas de 2025 - Trailers y análisis",
    channel: "Cine y Series",
    channelAvatar: "C",
    views: "1.1M vistas",
    uploadedAt: "hace 5 días",
  },
  {
    id: "12",
    thumbnail: "https://images.unsplash.com/photo-1560807707-8cc77767d783?w=640&h=360&fit=crop",
    duration: "10:42",
    title: "Los animales más tiernos del internet - Compilación de mascotas adorables",
    channel: "Animal Planet",
    channelAvatar: "A",
    views: "6.8M vistas",
    uploadedAt: "hace 2 días",
  },
]

export function VideoGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {videos.map((video) => (
        <VideoCard
          key={video.id}
          thumbnail={video.thumbnail}
          duration={video.duration}
          title={video.title}
          channel={video.channel}
          channelAvatar={video.channelAvatar}
          views={video.views}
          uploadedAt={video.uploadedAt}
        />
      ))}
    </div>
  )
}
