"use client"

import { Menu, Search, Mic, Video, Bell, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function Header({ onMenuClick }: { onMenuClick: () => void }) {
  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-background z-50 flex items-center justify-between px-4 border-b border-border">
      {/* Left section */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onMenuClick} className="shrink-0">
          <Menu className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-1">
          <div className="flex items-center">
            <svg viewBox="0 0 90 20" className="h-5 w-auto">
              <g fill="none">
                <path
                  d="M27.9727 3.12324C27.6435 1.89323 26.6768 0.926623 25.4468 0.597366C23.2197 0 14.285 0 14.285 0C14.285 0 5.35042 0 3.12323 0.597366C1.89323 0.926623 0.926623 1.89323 0.597366 3.12324C0 5.35042 0 10 0 10C0 10 0 14.6496 0.597366 16.8768C0.926623 18.1068 1.89323 19.0734 3.12323 19.4026C5.35042 20 14.285 20 14.285 20C14.285 20 23.2197 20 25.4468 19.4026C26.6768 19.0734 27.6435 18.1068 27.9727 16.8768C28.5701 14.6496 28.5701 10 28.5701 10C28.5701 10 28.5677 5.35042 27.9727 3.12324Z"
                  fill="#FF0000"
                />
                <path d="M11.4253 14.2854L18.8477 10.0004L11.4253 5.71533V14.2854Z" fill="white" />
              </g>
              <g fill="currentColor">
                <path d="M34.6024 19.2493V1.63896H38.1453V15.9873H44.8877V19.2493H34.6024Z" />
                <path d="M55.8374 19.2493H52.0058V18.3063C51.0533 19.1203 49.8488 19.5283 48.3923 19.5283C47.0508 19.5283 45.9258 19.0733 45.0173 18.1633C44.1088 17.2533 43.6543 16.1233 43.6543 14.7733C43.6543 13.4233 44.1323 12.3173 45.0883 11.4553C46.0443 10.5933 47.2318 10.1623 48.6508 10.1623C49.9688 10.1623 51.0773 10.4613 51.9743 11.0593V10.4143C51.9743 8.70233 50.8883 7.84633 48.7163 7.84633C47.0508 7.84633 45.6548 8.26633 44.5283 9.10633L43.6778 6.71433C45.1538 5.78133 47.0048 5.31433 49.2308 5.31433C51.1633 5.31433 52.7003 5.77633 53.8423 6.70033C54.9843 7.62433 55.5553 8.98033 55.5553 10.7683V18.0833C55.5553 18.3683 55.6153 18.5633 55.7353 18.6683C55.8553 18.7733 56.0743 18.8263 56.3923 18.8263H55.8373L55.8374 19.2493ZM51.9743 15.6323V13.3373C51.2463 12.7393 50.3618 12.4403 49.3208 12.4403C48.4508 12.4403 47.7468 12.6723 47.2088 13.1363C46.6708 13.6003 46.4018 14.2063 46.4018 14.9543C46.4018 15.7023 46.6478 16.2993 47.1398 16.7453C47.6318 17.1913 48.2808 17.4143 49.0868 17.4143C50.2288 17.4143 51.1868 16.8203 51.9743 15.6323Z" />
                <path d="M64.0963 19.5283C62.1403 19.5283 60.5628 18.9073 59.3638 17.6653C58.1648 16.4233 57.5653 14.7893 57.5653 12.7633V12.0893C57.5653 9.96133 58.1648 8.26933 59.3638 7.01333C60.5628 5.75733 62.1403 5.12933 64.0963 5.12933C66.0523 5.12933 67.6298 5.75733 68.8288 7.01333C70.0278 8.26933 70.6273 9.96133 70.6273 12.0893V12.7633C70.6273 14.7893 70.0278 16.4233 68.8288 17.6653C67.6298 18.9073 66.0523 19.5283 64.0963 19.5283ZM64.0963 16.8183C65.1373 16.8183 65.9663 16.4533 66.5833 15.7233C67.2003 14.9933 67.5088 14.0173 67.5088 12.7953V12.0573C67.5088 10.8353 67.2003 9.85933 66.5833 9.12933C65.9663 8.39933 65.1373 8.03433 64.0963 8.03433C63.0553 8.03433 62.2263 8.39933 61.6093 9.12933C60.9923 9.85933 60.6838 10.8353 60.6838 12.0573V12.7953C60.6838 14.0173 60.9923 14.9933 61.6093 15.7233C62.2263 16.4533 63.0553 16.8183 64.0963 16.8183Z" />
                <path d="M80.6283 19.2493L76.6113 13.5693L74.5893 15.6333V19.2493H71.0463V0.809326H74.5893V11.5033L80.0253 5.40933H84.1713L78.4653 11.7253L84.4923 19.2493H80.6283Z" />
              </g>
            </svg>
            <span className="text-[10px] text-muted-foreground align-top ml-0.5 font-medium">MX</span>
          </div>
        </div>
      </div>

      {/* Center - Search */}
      <div className="flex items-center gap-2 flex-1 max-w-2xl mx-4">
        <div className="flex flex-1">
          <Input
            type="text"
            placeholder="Buscar"
            className="rounded-r-none border-r-0 h-10 bg-background focus-visible:ring-0 focus-visible:ring-offset-0 focus-visible:border-blue-500"
          />
          <Button variant="outline" className="rounded-l-none h-10 px-6 bg-secondary hover:bg-secondary/80">
            <Search className="h-5 w-5" />
          </Button>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full bg-secondary hover:bg-secondary/80">
          <Mic className="h-5 w-5" />
        </Button>
      </div>

      {/* Right section */}
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" className="rounded-full">
          <Video className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full relative">
          <Bell className="h-5 w-5" />
          <span className="absolute top-1 right-1 h-4 w-4 bg-primary text-primary-foreground text-[10px] rounded-full flex items-center justify-center">
            3
          </span>
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full ml-2">
          <div className="h-8 w-8 rounded-full bg-purple-600 flex items-center justify-center">
            <User className="h-5 w-5 text-white" />
          </div>
        </Button>
      </div>
    </header>
  )
}
