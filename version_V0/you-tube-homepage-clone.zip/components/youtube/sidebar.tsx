"use client"

import { 
  Home, 
  Compass, 
  PlaySquare, 
  Clock, 
  ThumbsUp, 
  ChevronDown,
  Flame,
  Music2,
  Gamepad2,
  Newspaper,
  Trophy,
  Lightbulb,
  Shirt,
  Radio,
  Settings,
  Flag,
  HelpCircle,
  MessageSquareWarning
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"

const mainNav = [
  { icon: Home, label: "Inicio", active: true },
  { icon: Compass, label: "Shorts" },
  { icon: PlaySquare, label: "Suscripciones" },
]

const personalNav = [
  { icon: PlaySquare, label: "Tu canal" },
  { icon: Clock, label: "Historial" },
  { icon: PlaySquare, label: "Tus videos" },
  { icon: Clock, label: "Ver más tarde" },
  { icon: ThumbsUp, label: "Videos que me gustan" },
]

const subscriptions = [
  { name: "MrBeast en Español", avatar: "M" },
  { name: "Luisito Comunica", avatar: "L" },
  { name: "El Rubius", avatar: "E" },
  { name: "Auronplay", avatar: "A" },
  { name: "Ibai", avatar: "I" },
]

const exploreNav = [
  { icon: Flame, label: "Tendencias" },
  { icon: Music2, label: "Música" },
  { icon: Gamepad2, label: "Videojuegos" },
  { icon: Newspaper, label: "Noticias" },
  { icon: Trophy, label: "Deportes" },
  { icon: Lightbulb, label: "Aprendizaje" },
  { icon: Shirt, label: "Moda y belleza" },
  { icon: Radio, label: "Podcasts" },
]

const moreNav = [
  { icon: Settings, label: "Configuración" },
  { icon: Flag, label: "Historial de denuncias" },
  { icon: HelpCircle, label: "Ayuda" },
  { icon: MessageSquareWarning, label: "Enviar comentarios" },
]

interface SidebarProps {
  isOpen: boolean
}

export function Sidebar({ isOpen }: SidebarProps) {
  if (!isOpen) {
    return (
      <aside className="fixed left-0 top-14 w-[72px] h-[calc(100vh-56px)] bg-background z-40 hidden md:flex flex-col items-center pt-2 gap-1">
        {mainNav.map((item) => (
          <Button
            key={item.label}
            variant="ghost"
            className={cn(
              "flex flex-col items-center justify-center h-auto py-4 px-1 w-16 gap-1.5",
              item.active && "bg-accent"
            )}
          >
            <item.icon className="h-5 w-5" />
            <span className="text-[10px]">{item.label}</span>
          </Button>
        ))}
      </aside>
    )
  }

  return (
    <aside className="fixed left-0 top-14 w-60 h-[calc(100vh-56px)] bg-background z-40 border-r border-border">
      <ScrollArea className="h-full">
        <div className="py-3 px-3">
          {/* Main navigation */}
          <div className="space-y-1">
            {mainNav.map((item) => (
              <Button
                key={item.label}
                variant="ghost"
                className={cn(
                  "w-full justify-start gap-6 h-10 px-3 font-normal",
                  item.active && "bg-accent font-medium"
                )}
              >
                <item.icon className="h-5 w-5 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Button>
            ))}
          </div>

          <div className="border-t border-border my-3" />

          {/* Personal */}
          <div className="space-y-1">
            <div className="flex items-center gap-1 px-3 py-1.5">
              <span className="font-medium text-base">Tú</span>
              <ChevronDown className="h-4 w-4 rotate-[-90deg]" />
            </div>
            {personalNav.map((item) => (
              <Button
                key={item.label}
                variant="ghost"
                className="w-full justify-start gap-6 h-10 px-3 font-normal"
              >
                <item.icon className="h-5 w-5 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Button>
            ))}
          </div>

          <div className="border-t border-border my-3" />

          {/* Subscriptions */}
          <div className="space-y-1">
            <h3 className="px-3 py-1.5 font-medium text-base">Suscripciones</h3>
            {subscriptions.map((sub) => (
              <Button
                key={sub.name}
                variant="ghost"
                className="w-full justify-start gap-6 h-10 px-3 font-normal"
              >
                <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs shrink-0">
                  {sub.avatar}
                </div>
                <span className="truncate">{sub.name}</span>
              </Button>
            ))}
            <Button
              variant="ghost"
              className="w-full justify-start gap-6 h-10 px-3 font-normal"
            >
              <ChevronDown className="h-5 w-5 shrink-0" />
              <span>Mostrar más</span>
            </Button>
          </div>

          <div className="border-t border-border my-3" />

          {/* Explore */}
          <div className="space-y-1">
            <h3 className="px-3 py-1.5 font-medium text-base">Explorar</h3>
            {exploreNav.map((item) => (
              <Button
                key={item.label}
                variant="ghost"
                className="w-full justify-start gap-6 h-10 px-3 font-normal"
              >
                <item.icon className="h-5 w-5 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Button>
            ))}
          </div>

          <div className="border-t border-border my-3" />

          {/* More options */}
          <div className="space-y-1">
            {moreNav.map((item) => (
              <Button
                key={item.label}
                variant="ghost"
                className="w-full justify-start gap-6 h-10 px-3 font-normal"
              >
                <item.icon className="h-5 w-5 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Button>
            ))}
          </div>

          <div className="border-t border-border my-3" />

          {/* Footer */}
          <div className="px-3 py-2 text-xs text-muted-foreground space-y-3">
            <div className="flex flex-wrap gap-1.5">
              <span className="hover:cursor-pointer">Acerca de</span>
              <span className="hover:cursor-pointer">Prensa</span>
              <span className="hover:cursor-pointer">Derechos de autor</span>
              <span className="hover:cursor-pointer">Contacto</span>
              <span className="hover:cursor-pointer">Creadores</span>
              <span className="hover:cursor-pointer">Publicidad</span>
              <span className="hover:cursor-pointer">Desarrolladores</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <span className="hover:cursor-pointer">Condiciones</span>
              <span className="hover:cursor-pointer">Privacidad</span>
              <span className="hover:cursor-pointer">Políticas y seguridad</span>
              <span className="hover:cursor-pointer">Cómo funciona YouTube</span>
              <span className="hover:cursor-pointer">Probar funciones nuevas</span>
            </div>
            <p className="text-muted-foreground/70">© 2024 Google LLC</p>
          </div>
        </div>
      </ScrollArea>
    </aside>
  )
}
